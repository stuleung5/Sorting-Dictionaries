# Your names: 
# Bryan Leung
#
#
#
# no other modules allowed
import random,time,sys
class Dictionary:

    #### To complete
    def __init__(self, name="N/A"):
        self.__words = [] #private instance list for all my files
        self.__name = name #private name for all my files e.g. french_sorted.txt
        random.seed(8) #randomized seed for future random words and/or lists
        try:
            if self.__name=="N/A": #Added possibility
                x=5 #Automatically works
            else:
                f0=open(self.__name,"r") #Files I used exist
                f0.close() 
        except:
            print("File "+self.__name+' does not exist!')
            sys.exit(0) #Exit using sys import
        
        # For each existing file in the project, I open in read mode. Then, for each line, I add it to my list and remove '\n' as well
        # as split with commas.
        if name=='english.txt': 
            f1=open('english.txt','r')
            for line in f1:
                self.__words += [line.rstrip('\n').split(',')]
            f1.close()
        if name=='spanish.txt':
            f2=open('spanish.txt','r')
            for line in f2:
                self.__words += [line.rstrip('\n').split(',')]
            f2.close()
        if name=='french.txt':
            f3=open('french.txt','r')
            for line in f3:
                self.__words += [line.rstrip('\n').split(',')]
            f3.close()
        if name=='short.txt':
            f4=open('short.txt','r')
            for line in f4:
                self.__words += [line.rstrip('\n').split(',')]
            f4.close()
        if name=='short_sorted.txt':
            f5=open('short_sorted.txt','r')
            for line in f5:
                self.__words += [line.rstrip('\n').split(',')]
            f5.close()
        if name=='french_sorted.txt':
            f7=open('french_sorted.txt','r')
            for line in f7:
                self.__words += [line.rstrip('\n').split(',')]
            f7.close()
        if name=='english_sorted.txt':
            f8=open('english_sorted.txt','r')
            for line in f8:
                self.__words += [line.rstrip('\n').split(',')]
            f8.close()
        if name=='spanish_sorted.txt':
            f9=open('spanish_sorted.txt','r')
            for line in f9:
                self.__words += [line.rstrip('\n').split(',')]
            f9.close()

    # Get methods help call private instance variables
    def get_name(self):
        return self.__name

    def get_size(self):
        return len(self.__words)

    def get_random_list(self,int): #input as integer
        rand_new=[] #Signifies empty list of words to be used among dictionaries
        for i in range(0,int):
            rand_new+=self.__words[random.randint(0,self.get_size()-1)]
        return rand_new #Get how many random words I inputed.
  
    #Append list
    def insert(self,add):
        return self.__words.append(add)
    
    #Display one word every line
    def display(self):
        for i in range(0,len(self.__words)):
            print(self.__words[i])
    
    #Calculate time to shuffle words 
    def shuffle(self):
        t1 = time.process_time()
        n=len(self.__words)
        for out in range(n-1,0,-1): #using out loop
            index=random.randint(0,out) #random value
            self.__words[out],self.__words[index]=self.__words[index],self.__words[out] #Swap indexes
        t2 = time.process_time()
        return t2-t1

    # Linear search scanning from first index to last index
    def lsearch(self,input):
        self.__index = 0 #Index starting point
        for i in range(0,len(self.__words)):
            if self.__words[i]==input:
                return True
            else:
                self.__index+=1 #Reveals index number that is True.
        self.__index=-1 #Index is -1 if False
        return False
    # Binary search scanning by approximate intervals of two in a sorted list
    def bsearch(self,input):
        low = 0 
        high = len(self.__words)-1   
        self.__steps = 0 #Number of steps initially at zero. 
        while low<=high:
            mid = low + (high - low)//2 
            if list(self.__words[mid])==[input]:
                self.__index=mid
                self.__steps+=1 #If True finally add last one.
                return True
            elif list(self.__words[mid])<[input]:
                low = mid + 1
                self.__steps+=1 #If False add one
            else:
                high = mid - 1
                self.__steps+=1 #If False add one
        self.__index = low 
        """                Reveals index where false word can be inserted. 
                           Later, I use this to place an unsorted variable 
                           among sorted variables in method binarySearchIndex.                             """
        self.__steps+=1 #If False add one
        return False 
    
    #Get methods
    def get_steps(self):
        return self.__steps

    def get_index(self):
        return self.__index 

    def insertion_sort(self):
        t1 = time.process_time()
        n=len(self.__words)
        for index in range(1,n): #outer loop
            key=self.__words[index] #select and store key/pivot
            shift=index #Shift starts at key
            while shift>0 and self.__words[shift-1]>key: #Check previous ones by linearly until index zero
                self.__words[shift]=self.__words[shift-1] #shift key
                shift-=1 #Increment one step down
                self.__words[shift]=key #insertion
        t2 = time.process_time()
        return t2-t1
    '''Very similar to bsearch. Main difference is binarySearchIndex 
       returns 'low'(insert value) for the 'key' variable. In bsearch,
       I have to return a boolean.
    '''
    def binarySearchIndex(self, indx_for_shifting, keyusing):
        low = 0
        high = indx_for_shifting
        while low < high:
            mid = (low + high)//2
            if self.__words[mid] <= keyusing:
                low = mid + 1
            else:
                if mid>=1:
                    high = mid - 1
                else:
                    high=0
        return low
    
    def enhanced_insertion_sort(self):
        t1=time.process_time()
        n=len(self.__words)
        for index in range(1,n):
            key=self.__words[index] #Key is the index starting at 1.
            located = self.binarySearchIndex(index,key) #Using binary for each key raising by one index in for loop.
            shift=index #Store index value that can be potentially shifted
            while index>0 and shift>located: #If located value is greater than key index, and index is greater than 0. 
                self.__words[shift]=self.__words[shift-1] #Shift values greater than key index to the right
                shift-=1 
            self.__words[located]=key #Insert key into the located right spot based on binary search
        t2=time.process_time()
        return t2-t1
    
    #Save files based on name. Write down key information from self.__word list. 
    def save(self,name):
        f6=open(name,"w")
        for i in range(0,len(self.__words)):
            f6.write(str(self.__words[i][0])+"\n")
        f6.close()
        print("Save "+name)

    def spell_check(self,analyze):
        try: 
            f10=open(analyze,'r') #If file can be read, it exists
        except:
            print("File "+self.__name+' does not exist!')
            sys.exit(0) #Exit properly
        f10=open(analyze,'r') #Read file for preperation

        #Create two seperate lists: one for original and other for changed. 
        self.__changedtext=[]
        self.__originaltext=[]
        
        #Replace punctuation with nothing. Strip ',- for French and Spanish. 
        for lines in f10:
            self.__changedtext+=[lines.lower().rstrip("\n").strip('!').strip('\'').replace('.','').replace('?','').
            replace('(','').replace(')','').strip('-').replace('[','').replace(']','').replace('{','').replace(',','').
            replace('}','').replace(';','').replace(':','').replace('\"','').replace('\\','').
            replace('<','').replace('>','').replace('/','').replace('@','').replace('#','').replace('$','').
            replace('%','').replace('^','').replace('&','').replace('*','').replace('_','').replace('~','').
            split()]
            self.__originaltext+=[lines.split()]
        
        """self.__changedtext is a list of lists of strings, so I use two four loops. Through binary search of dictionary
           chosen, if any word is False, I would put parenthesis around self.__originaltext."""
        for i in range(0,len(self.__changedtext)):
            for j in range(0,len(self.__changedtext[i])):
                if self.bsearch(self.__changedtext[i][j])==False:
                    self.__originaltext[i][j]="("+self.__originaltext[i][j]+")"
        self.__emptylist=[0]*len(self.__originaltext)

        """Finally, now that I have self.__originaltext with modifications, my plan is to go from list(list(str)) to list(str). To do this,
            I scan str using two for loops. Then, using self.__emptylist, I put each line of strings for each index in self.__emptylist.
            Finally, I can self.__emptylist and print out the text. """
        for k in range(0,len(self.__originaltext)):
            self.__emptyStr=""
            for l in range(0,len(self.__originaltext[k])):
                self.__emptyStr+=str(self.__originaltext[k][l])+" "
            self.__emptylist[k]=self.__emptyStr

        print() #Create one new line
        for m in range(0,len(self.__emptylist)):
            print(self.__emptylist[m])
        f10.close()

    @staticmethod
    def sort_word(word):  # to complete
        """ must return a string with letters included in 'word' that are now sorted"""
        list_word=list(word)
        ordered_word=""
        n=len(list_word)
        for index in range(1,n): #outer loop
            key=list_word[index] #select and store key/pivot
            shift=index #Shift starts at key
            while shift>0 and list_word[shift-1]>key: #Check previous ones by linearly until index zero
                list_word[shift]=list_word[shift-1] #shift key
                shift-=1 #Increment one step down
                list_word[shift]=key #insertion
        for i in range(0,n):
            ordered_word+=list_word[i]
        return ordered_word
        

    def anagram(self,input):
        self.__possibilities=[]
        self.__narrowed_down=[]
        dict4=Dictionary()
        ult_key=dict4.sort_word(input)
        for i in range(0,len(self.__words)):
            for j in range(0,len(input)):
                if len(input)==len(self.__words[i][0]) and input[j] in self.__words[i][0]:
                    self.__possibilities+=self.__words[i]
        for k in range(0,len(self.__possibilities),4):
            if dict4.sort_word(self.__possibilities[k])==ult_key:
                self.__narrowed_down+=[self.__possibilities[k]]
        return self.__narrowed_down
    
    def compute_score_scrabble(self):
        self.__list_of_int=[]
        return
    def selection_sort(self):    #provided to you
        """Perfom selection sort, must return the time it takes to sort the list of words
        Remark: Routine works 'in-place'"""
        t1 = time.process_time() #capture time
        n=self.get_size()
        for out in range(n-1):        #outer loop
            #find minimum between out+1 and n-1
            imin=out
            for i in range(out+1,n):  #inner loop
                if self.__words[i]<self.__words[imin]: 
                    imin=i #update  minimum index
            #swap (3 step here)
            temp=self.__words[imin]
            self.__words[imin]=self.__words[out]
            self.__words[out]=temp
        t2 = time.process_time() #capture time
        return t2-t1

    
    @staticmethod  # provided to you
    def get_word_combination(word, combs=['']):
        """ return a list that contains all the letter combinations (all length) of the input 'word' """
        if len(word) == 0:
            return combs
        head, tail = word[0], word[1:]
        combs = combs + list(map(lambda x: x+head, combs))
        return Dictionary.get_word_combination(tail, combs)







########################################################################
########################################################################


def main():

    ### step-1 test constructor
    name=input("Enter dictionary name (from file 'name'.txt): ")    
    dict1=Dictionary(name+".txt")

    ### step-2 test get_name, get_size, get_random_list        
    print('Name first dictionary:',dict1.get_name())   
    print('Size first dictionary:',dict1.get_size()) 
    print("Five random words:",end=" ")
    rlist=dict1.get_random_list(5) # 5 means the number of random words we want
    for w in rlist: print(w,end=" ")
    print("\n")

    ### step-3 test constructor again
    dict2=Dictionary()
    print('Name second dictionary:',dict2.get_name())
    
    ### step-4 test insert and display
    for w in rlist: dict2.insert(w)
    print('Display second dictionary:')
    dict2.display()

    ### step-5 test shuffle 
    t=dict2.shuffle()
    print('\nSecond dictionary shuffled in %ss:'%t)
    print('Display second dictionary:')
    dict2.display()

    ### step-6 test linear search
    word="morning"
    print("\nLinear search for the word '%s' in second dictionary"%word)
    status=dict2.lsearch(word)
    print("Is '%s' found: %s at index %s"%(word,status,dict2.get_index()))

    ### sort second using selection sort (provided to you)
    t=dict2.selection_sort()
    print('\nSecond dictionary sorted in %ss:'%t)
    print('Display second dictionary:')
    dict2.display()

    ### step-7 test binary search (find it)
    word="morning"
    print("\nBinary search for the word '%s' in second dictionary"%word)
    status=dict2.bsearch(word)
    print("Is '%s' found: %s at index %s"%(word,status,dict2.get_index()))

    # binary search (did no find it)
    word="ning"
    print("\nBinary search for the word '%s' in second dictionary"%word)
    status=dict2.bsearch(word)
    print("'%s' is not found so it must be inserted at index %s"%(word,dict2.get_index()))
    

    


## call the main function if this file is directly executed
if __name__=="__main__":
    main()
